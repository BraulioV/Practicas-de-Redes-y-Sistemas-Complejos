#!/bin/bash
# Used to check the runtime.

#MPATH=/home/ECSC/aquirin/AQUIRIN/program/VisualScienceMaps
#CPATH=/home/ECSC/aquirin/AQUIRIN/program/VisualScienceMaps/CheckNets/create
MPATH=..
CPATH=../CheckNets/create

SIZE=$1
SYMETRY=1
DIAGVALUE=0
TYPE=1		# 0: int, 1: float
MIN=1
MAX=999
PROBAINFINITY=0.0

# Chronometer all the algorithms on all the maps

#LISTALGO="$MPATH/Original-Pathfinder/origpf-C1 $MPATH/Binary-Pathfinder/binpf-C18 $MPATH/Fast-Pathfinder/fastpf-C235 $MPATH/MST-Pathfinder/mstpf-prac-C5000 $MPATH/MST-Pathfinder/mstpf-theo-C5000"
LISTALGO="$MPATH/Original-Pathfinder/origpf-C1 $MPATH/Binary-Pathfinder/binpf-C1 $MPATH/Fast-Pathfinder/fastpf-C1 $MPATH/MST-Pathfinder/mstpf-prac-C1 $MPATH/MST-Pathfinder/mstpf-theo-C1"

if [ $SIZE -eq 100 ]
then
	LISTALGO="$MPATH/Fast-Pathfinder/fastpf-C2000 $MPATH/MST-Pathfinder/mstpf-prac-C500 $MPATH/MST-Pathfinder/mstpf-theo-C500"
elif [ $SIZE -eq 200 ]
then
	LISTALGO="$MPATH/Fast-Pathfinder/fastpf-C300 $MPATH/MST-Pathfinder/mstpf-prac-C500 $MPATH/MST-Pathfinder/mstpf-theo-C500"
elif [ $SIZE -eq 300 ]
then
        LISTALGO="$MPATH/Fast-Pathfinder/fastpf-C80 $MPATH/MST-Pathfinder/mstpf-prac-C500 $MPATH/MST-Pathfinder/mstpf-theo-C500"
elif [ $SIZE -eq 400 ]
then
        LISTALGO="$MPATH/Fast-Pathfinder/fastpf-C40 $MPATH/MST-Pathfinder/mstpf-prac-C400 $MPATH/MST-Pathfinder/mstpf-theo-C400"
elif [ $SIZE -eq 1000 ]
then
        LISTALGO="$MPATH/Fast-Pathfinder/fastpf-C5 $MPATH/MST-Pathfinder/mstpf-prac-C50 $MPATH/MST-Pathfinder/mstpf-theo-C50"
elif [ $SIZE -eq 10000 ]
then
        LISTALGO="$MPATH/MST-Pathfinder/mstpf-prac-C5 $MPATH/MST-Pathfinder/mstpf-theo-C5"
fi

echo "PARAMS: $SIZE $SYMETRY $DIAGVALUE $TYPE $MIN $MAX $PROBAINFINITY"
echo $LISTALGO

#while true
for i in `seq 1 30`
do

map=/tmp/mapadapt.$i.$1.net
$CPATH $SIZE $SYMETRY $DIAGVALUE $TYPE $MIN $MAX $PROBAINFINITY > $map

for algo in `echo $LISTALGO`
do
		TPS=`($algo $map > /dev/null) 2>&1 | cut -f3 -d' '`
		#printf "%s %s " $algo $map
		#($algo $map > /dev/null) | grep "Temps"
		printf "$TPS "
done
printf "\n"

rm -f $map

done

